#!/usr/bin/env python

#importing the nescessary modules
from datetime import date
import sys

import cartopy
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import cartopy.io.img_tiles as cimgt
import cartopy.mpl.geoaxes
#import cartopy.io.shapereader as shpreader

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from matplotlib.offsetbox import AnchoredText

## Below follow three options for the visualization of the input location

#Ceates an overview map with an inset
#showing a regional view of the input location
def Global_and_inset(InputLocation, InputLocationName=None, ArtistName=None, MapTitle=None, MapSize=None, RegionalZoom=None):

	#Default values for options:
	if InputLocation == None:
		print("No inputlocation provided, please provide a list of coordinate tuples")
	if InputLocationName == None or InputLocationName == "":
		InputLocationName = "location"
	if MapTitle == None or MapTitle == "":
		MapTitle = "location on a global and regional scale"
	if ArtistName == None or ArtistName == "":
		ArtistName = "Cartopy" 
	if MapSize == None or MapSize == "":
                MapSize = 10
	if RegionalZoom == None or RegionalZoom == "":
		RegionalZoom = 5

	RegionalZoom = int(RegionalZoom)
	MapSize = int(MapSize)
	Today = date.today()
	Year = Today.strftime("%Y")

	#Initializing Geographic information
	InputLocationPoint = InputLocation[0]
	central_lon = InputLocationPoint[0]
	central_lat = InputLocationPoint[1]
	regional_extent = [central_lon-RegionalZoom,central_lon+RegionalZoom,central_lat-RegionalZoom,central_lat+RegionalZoom]

	#creating a global map with regional inset
	fig = plt.figure(figsize=(MapSize,MapSize))
	detailed_terrain= cimgt.Stamen('terrain-background')
	global_map = plt.axes(projection=detailed_terrain.crs)
	global_map.coastlines(resolution='50m')
	global_map.stock_img()
	global_map.gridlines()
	global_map.scatter(InputLocationPoint[0], InputLocationPoint[1], color='red', transform=ccrs.PlateCarree())
	plt.text(InputLocationPoint[0], InputLocationPoint[1], InputLocationName, transform=ccrs.PlateCarree())

	#Defining the inset
	fig.add_subplot()
	regional_map = plt.axes(projection=detailed_terrain.crs)
	inset = inset_axes(regional_map, width='35%', height='25%', loc='upper right', 
                   	axes_class=cartopy.mpl.geoaxes.GeoAxes, 
                   	axes_kwargs=dict(map_projection=ccrs.PlateCarree()))
	inset.coastlines()
	inset.set_extent(regional_extent, ccrs.PlateCarree())
	inset.add_image(detailed_terrain, 8)
	inset.scatter(InputLocationPoint[0], InputLocationPoint[1], color='red', transform=ccrs.PlateCarree())

	#adding Title and Artist box
	global_map.set_title(MapTitle,fontdict={'fontsize': 16})
	Artist_text = AnchoredText(r'(c) {} {}'.format(Year, ArtistName), loc=4, prop={'size': 12}, frameon=True)
	global_map.add_artist(Artist_text)

	#saving the output (before plt.show!)
	plt.savefig('./output/{}.png'.format(MapTitle))
	plt.show()

#Create a global map in Orthographic projection
def RoundEarth(InputLocation, InputLocationName=None, ArtistName=None, MapTitle=None, MapSize=None):

	#Default values for options:
	Today = date.today()
	Year = Today.strftime("%Y")

	if InputLocationName == None or InputLocationName == "":
		InputLocationName = "location"
	if MapTitle == None or MapTitle == "":
		MapTitle = "location on globe"
	if ArtistName == None or ArtistName == "":
		ArtistName = "Cartopy"
	if MapSize == None or MapSize == "":
		MapSize = 10

	MapSize = int(MapSize)

	#initializing Geographic information
	InputLocationPoint = InputLocation[0]
	central_lon = InputLocationPoint[0]
	central_lat = InputLocationPoint[1]

	#plotting figure
	fig = plt.figure(figsize=(MapSize,MapSize))
	global_map = plt.axes(projection=ccrs.Orthographic(central_longitude=central_lon, central_latitude=central_lat))
	global_map.coastlines(resolution='50m')
	global_map.stock_img()
	global_map.gridlines()
	global_map.scatter(InputLocationPoint[0], InputLocationPoint[1], color='red', transform=ccrs.PlateCarree())
	plt.text(InputLocationPoint[0], InputLocationPoint[1], InputLocationName, transform=ccrs.PlateCarree())

	#adding Title and Artist box
	global_map.set_title(MapTitle,fontdict={'fontsize': 16})
	Artist_text = AnchoredText(r'(c) {} {}'.format(Year, ArtistName), loc=4, prop={'size': 12}, frameon=True)
	global_map.add_artist(Artist_text)

	#Saving and showing the map
	plt.savefig('./output/{}.png'.format(MapTitle))
	plt.show()


#Create a global map of the location in a custom projection
def CustomProjection(InputLocation=None, InputLocationName=None, ArtistName=None, MapTitle=None, MapSize=None, proj=None):


	#Dictionary of possible projections
	projectionLib = {"1": 'PlateCarree',
			"2": 'Robinson',
			"3": 'Mercator',
			"4": 'EqualEarth',
			"5": 'InterruptedGoodeHomolosine'
              		}

	#Default values for options:
	if proj == None or proj == "":
		projection = projectionLib['1']
	else:
		projection = projectionLib[proj]
	if InputLocation == None:
		print("No inputlocation provided, please provide a list of coordinate tuples")
	if InputLocationName == None or InputLocationName == "":
		InputLocationName = "location"
	if MapTitle == None or MapTitle == "":
		MapTitle = "location"
	if ArtistName == None or ArtistName == "":
		ArtistName = "Cartopy" 
	if MapSize == None or MapSize == "":
		MapSize = 10

	Today = date.today()
	Year = Today.strftime("%Y")
	InputLocationPoint = InputLocation[0]
	central_lon = InputLocationPoint[0]
	MapSize = int(MapSize)


	#plot figure
	fig = plt.figure(figsize=(MapSize,MapSize))

	#plotting in different projectionas
	if projection == 'PlateCarree':
		map = plt.axes(projection=ccrs.PlateCarree(central_longitude=central_lon))
	if projection == 'Robinson':
		map = plt.axes(projection=ccrs.Robinson(central_longitude=central_lon))
	if projection == 'Mercator':
		map = plt.axes(projection=ccrs.Mercator(central_longitude=central_lon))
	if projection == 'EqualEarth':
		map = plt.axes(projection=ccrs.EqualEarth(central_longitude=central_lon))
	if projection == 'InterruptedGoodeHomolosine':
		map = plt.axes(projection=ccrs.InterruptedGoodeHomolosine(central_longitude=central_lon))

	#Adding details
	map.coastlines(resolution='50m')
	map.stock_img()
	map.gridlines()
	map.scatter(InputLocationPoint[0], InputLocationPoint[1], color='red', transform=ccrs.PlateCarree())
	plt.text(InputLocationPoint[0], InputLocationPoint[1], InputLocationName, transform=ccrs.PlateCarree())

	#Adding Title and Artist box
	map.set_title(MapTitle,fontdict={'fontsize': 16})
	Artist_text = AnchoredText(r'(c) {} {}'.format(Year, ArtistName), loc=4, prop={'size': 12}, frameon=True)
	map.add_artist(Artist_text)

	#saving and showing output
	plt.savefig('./output/{}.png'.format(MapTitle))
	plt.show()

# Polygon plotting is not supported in this Version
	#global_map = plt.axes(projection=ccrs.PlateCarree(central_longitude=central_lon))
	#inset.add_geometries([site_coordinates], crs=ccrs.PlateCarree(), facecolor = 'b', edgecolor='black', alpha=0.8)

