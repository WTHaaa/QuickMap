#!/usr/bin/env python

#importing modules
#from shapely.geometry.polygon import Polygon	#Polygon support not included in this version.
import re
import sys
from pathlib import Path as path

def KML_parser(input_filename=None,OutputType=None):

	#Opening file and setting variables
	input_file = open(input_filename, 'r')
	regex_search = '(\-*\d+\.\d+),(\-*\d+\.\d+)'
	Site_boundary_list = []

	#read lines, use ReGex to find & parse coordinates, convert to tuples, create list of tuples
	for line in input_file:
    		coordinate = re.search(regex_search,line)
    		if coordinate != None:
        		Lon = float(coordinate.group(1))
        		Lat = float(coordinate.group(2))
        		Tuple_Lon_Lat = tuple((Lon,Lat))
        		Site_boundary_list.append(Tuple_Lon_Lat)

	#Close file and create shapely polygon from list of tuples, to be used by Geographic Visualization module
	#Site_boundary_polygon = Polygon(Site_boundary_list)             #Polygon support not included in this version.

	#returning the data:
	if OutputType == None:
		return Site_boundary_list
	#if OutputType == "polygon":                              #Polygon support not included in this version.
		#return Site_boundary_polygon
	input_file.close()

#create option for use as standalone in a pipeline
if __name__ == "__main__":
	print(KML_parser(sys.argv[1]))
