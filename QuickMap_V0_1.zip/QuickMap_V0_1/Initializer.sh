#!/bin/bash

echo "----------------------------------------------------------"
echo "This script automatically configures QuickMaps' python scripts and downloads required modules."
echo "The application needs Anaconda to function properly. If you do not have a recent version of Anaconda installed, please do so before continuing."
echo "press any key to continue, or ctrl-C to terminate"
echo "---------------------------------------------------------"
read key

#chmod u+x MainScript.py
#chmod u+x ImportModule.py
#chmod u+x GeoVizMod.py
pip install shapely
pip install cartopy

