#######	 ReadMe-file for QuickMap V0.1  #########
	
QuickMap V0.1, an application developed by Thomas Heger (950206317060)
	for the WUR course "Practical Computing for Biologists 
	(September and October 2020)       

QuickMap V0.1 quickly visualizes a farm location from .kml files. 

Quickstart guide:

1. Give execution permission to MainScript.py (by using chmod u+x MainScript.py)
2. Execute MainScript and follow the instructions. The application will provide you 
	with the option to automatically download and install required modules.
3. You can use one of the supplied example .kml files, such as Example.kml, 
	to test how the application works.
4. Once you are ready to use QuickMap on your own .kml files, provide the absolute path of the .kml
	file you would like to visualize.
5. Find your map(s) in the output folder!

Note: Map output might take between 10 and 20 seconds to accomplish, depending on your
computer. Please be patient; the application is quick but not instant!

Good luck!


https://github.com/WTHaaa/QuickMap
---ReadMe for QuickMap V0.1 by Thomas Heger --- 9-10-2020 --- thomas-heger(at)outlook.com----

