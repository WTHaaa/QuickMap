#!/usr/bin/env python

#Main Script of this application.
#Goal: To take user input to configure application behavior.

# -->potential improvements: include option to unzip .kmz file and
# 	-->include "ls" command to show filenames of potential files
# 	-->include a user profile so settings are remembered, and the user isn't asked to initialize every time.
#	-->create while loop to allow user to produce multiple maps in a single session

#importing 
import os
from pathlib import Path as path
from GeographicalVisualizationModule import Global_and_inset
from GeographicalVisualizationModule import RoundEarth
from GeographicalVisualizationModule import CustomProjection 
from ImportModule import KML_parser


#Welcome and initialization
print("welcome to QuickMap V0.1. This application plots .kml files onto a map to create a quick location overview\n")
print("It is recommended to run the Initializer.sh script if this is the first use of this application.\n Would you like to do so now?")
if input("(y/)n").upper() == "Y":
	os.system("chmod u+x Initializer.sh")
	os.system("./Initializer.sh")
	print("initialization complete") 

print("--------------Input------------------------")

print("The following KML files are available in the QuickMap examples directory:\n")
os.system("ls ./*/*.kml")

KML_path = input('\nAbsolute/relative path of input .kml file:')
IM_output = KML_parser(KML_path) #Parsing Coordinates from .kml file using ImportModule

#user choices
print("The following coordinates were found: \n{}.".format(IM_output))
Cont1 = input("would you like to produce a map from these coordinates? (y/n)\n").upper()
print("--------------Processing-------------------")
Cont2 = input("Please select the map type you would like to produce:\n 1) Global overview with inset; \n 2) Globe (orthographic) with location; \n 3) Global map in a custom projection with location")

if Cont1 == "Y":	#Takes input for map layout
	print("---------------Map options--------------------------\n Please provide the following information: (leave blank for default)")
	InputLocationName = input("What is the name of this location?")
	ArtistName = input("What is the name of the map maker?")
	MapTitle = input("What is map title?")
	MapSize = input("What map size would you like? (input value between 1 and 20)") 
	print("-------------Producing map----------------------------")

	if Cont2 == "1":	#Each option creates output folder and activates Geographical Visualization Module
		RegionalZoom = input("Wait, one more question: how much would you like the regional inset to be zoomed in? (provide number between 1(close) and 10(far off)):")
		OutputFolder = path("./output")
		if OutputFolder.exists() == False:
			OutputFolder.mkdir()
		Global_and_inset(IM_output, InputLocationName, ArtistName, MapTitle, MapSize, RegionalZoom)
		print("your map was produced successfully. You can find it in the output folder")

	if Cont2 == "2":
		OutputFolder = path("./output")
		if OutputFolder.exists() == False:
			OutputFolder.mkdir()
		RoundEarth(IM_output, InputLocationName, ArtistName, MapTitle, MapSize)
		print("your map was produced successfully. You can find it in the output folder")

	if Cont2 == "3":
		Proj = input("one more question then: what projection would you like to use?\n 1: PlateCarree \n 2: Robinson\n 3: Mercator \n 4: EqualEarth \n 5: InterruptedGoodeHomolosine\n please specify a number between 1 and 5")
		OutputFolder = path("./output")
		if OutputFolder.exists() == False:
			OutputFolder.mkdir()
		CustomProjection(IM_output, InputLocationName, ArtistName, MapTitle, MapSize, Proj)
		print("your map was produced successfully. You can find it in the output folder")

print("---------------------------------------------------")
print("\nThank you for using QuickMap V0.1.\n Scripted by Thomas Heger (2020), thomas-heger(at)outlook.com.\n This software is distributed under the GNU GENERAL PUBLIC LICENSE Version 3.\n Feel free to re-use this code in any way, but please attribute the original author!" )
quit()







#def function(arg):
#	print(arg==kml)

#if __name__ = "__main__":
